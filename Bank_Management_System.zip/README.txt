How to config the project:


1. Please login the Gmail first for firebase access. if you don't login then you cant use firebase feature to store data and you have to config your own Gmail firebase manually.

Gmail : arakash5466@gmail.com
pass : arakasH.5466@


2. Before running the project open firebase and you can see SAMI-BankDB project database already exist in the project list.

3. Now open the project in any tab you want.

4. Admin email : admin@gmail.com 
password: admin123

5. To access user panel create any user account you want and then login into it.