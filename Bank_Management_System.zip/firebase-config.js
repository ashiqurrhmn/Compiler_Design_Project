// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// import { getAuth } from "firebase/auth";
// import { getFirestore } from "firebase/firestore";
// import { getStorage } from "firebase/storage";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDH17IMacG1MWF3t_DvkNvgASTP2iTn9AA",
  authDomain: "akash-f3f6f.firebaseapp.com",
  projectId: "akash-f3f6f",
  storageBucket: "akash-f3f6f.appspot.com", 
  messagingSenderId: "21948632353",
  appId: "1:21948632353:web:06c7dbf2e087c3440dc260"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Optionally, initialize and export other Firebase services here:
// const auth = getAuth(app);
// const db = getFirestore(app);
// const storage = getStorage(app);

export default app;